PIXEL TRANSLATE — ANDROID PAKETİ
=================================

Bu klasör, mevcut Pixel Translate web uygulamasını Capacitor ile Android
uygulamasına dönüştürmek için hazırlanmış kaynak pakettir. Bu ZIP'in içinde
henüz derlenmiş APK bulunmaz.

EN KOLAY YÖNTEM: GITHUB ÜZERİNDEN APK OLUŞTURMA
------------------------------------------------
1. Bu ZIP'i bilgisayarında aç.
2. İçindeki dosyaları GitHub'da yeni bir deponun ana dizinine yükle.
3. Deponun Actions sekmesine gir.
4. "Build Android APK" iş akışının tamamlanmasını bekle.
   İlk derleme birkaç dakika sürebilir.
5. Tamamlanan iş akışının sayfasındaki Artifacts bölümünden
   "pixel-translate-debug-apk" dosyasını indir.
6. ZIP içindeki app-debug.apk dosyası test amaçlı Android APK'dır.

BİLGİSAYARDA ANDROID STUDIO İLE DERLEME
---------------------------------------
Gerekenler: Node.js 22+, Android Studio ve Android SDK.
Capacitor Android belgeleri:
https://capacitorjs.com/docs/android

Komutlar:
  npm install
  npm run android:init
  node scripts/patch-android-manifest.mjs
  npm run android:sync
  npm run android:open

Android Studio açıldıktan sonra Build > Build Bundle(s) / APK(s) >
Build APK(s) seçeneğini kullan.

İZİNLER VE GİZLİLİK
-------------------
- Kamera izni, uygulama içinden kamera başlatıldığında Android tarafından
  sorulur. Mikrofon izni istenmez; uygulama mikrofon kullanmaz.
- İnternet izni, isteğe bağlı yapay zekâ ve model/engine indirmeleri için
  gereklidir.
- Claude API anahtarı uygulama içindeki sekme oturumunda tutulur. Bu,
  anahtarın dağıtılan APK içine gömülmediği anlamına gelir; yine de anahtarı
  paylaşma ve ücret sınırı belirle.
- Bu paket debug/test APK üretir. Google Play için ayrıca imzalı release
  AAB/APK, uygulama kimliği ve mağaza hazırlıkları gerekir.

TEST SINIRI
-----------
Bu çalışma ortamında Android SDK/Gradle kurulumu bulunmadığından burada
doğrudan APK derlenemedi. Kaynak proje ve otomatik APK derleme iş akışı
hazırlandı. Gerçek cihazda kamera, TTS, çevrimdışı model indirme ve
çeviri davranışı ayrıca test edilmelidir.

import fs from 'node:fs';

const file = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(file)) {
  console.error(`AndroidManifest.xml not found: ${file}. Run "npm run android:init" first.`);
  process.exit(1);
}

let xml = fs.readFileSync(file, 'utf8');
const permissions = [
  'android.permission.INTERNET',
  'android.permission.CAMERA'
];

for (const permission of permissions) {
  const tag = `<uses-permission android:name="${permission}" />`;
  if (!xml.includes(`android:name="${permission}"`)) {
    xml = xml.replace('<application', `    ${tag}\n    <application`);
  }
}

if (!xml.includes('android.hardware.camera')) {
  xml = xml.replace(
    '<application',
    '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <application'
  );
}

fs.writeFileSync(file, xml);
console.log('Android camera and internet permissions configured.');
